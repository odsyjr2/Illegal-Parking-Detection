import React, { useEffect, useRef, useState } from 'react';

function MapPage({ selectedLocation }) {
  const mapRef = useRef(null);
  const markerRef = useRef(null);
  const [map, setMap] = useState(null);

  useEffect(() => {
    // 스크립트가 이미 로드된 경우 중복 로드 방지
    if (window.kakao && window.kakao.maps) {
      initMap();
    } else {
      const script = document.createElement('script');
      script.src = `//dapi.kakao.com/v2/maps/sdk.js?appkey=cc0a3f17267a09a8e2670bb54f681f23`;
      script.async = true;
      document.head.appendChild(script);

      script.onload = () => {
        window.kakao.maps.load(() => {
          initMap();
        });
      };
    }

    function initMap() {
      const container = document.getElementById('map');
      const options = {
        center: new window.kakao.maps.LatLng(37.5665, 126.9780),
        level: 3,
      };
      const kakaoMap = new window.kakao.maps.Map(container, options);
      const marker = new window.kakao.maps.Marker({
        position: kakaoMap.getCenter(),
      });
      marker.setMap(kakaoMap);

      mapRef.current = kakaoMap;
      markerRef.current = marker;
      setMap(kakaoMap);
    }
  }, []);

  useEffect(() => {
    if (!selectedLocation || !mapRef.current || !markerRef.current) return;

    const { lat, lng } = selectedLocation;
    const newCenter = new window.kakao.maps.LatLng(lat, lng);

    mapRef.current.setCenter(newCenter);
    markerRef.current.setPosition(newCenter);
  }, [selectedLocation]);

  return (
    <div style={{ width: '100%', height: '100%' }}>
      <div
        id="map"
        style={{
          width: '100%',
          height: '100vh',
          backgroundColor: '#dff7eb',
        }}
      ></div>
    </div>
  );
}

export default MapPage;
